<?php 

#!/bin/bash

echo date('d.m.Y H:i'), ' Makarov Nikita'; 

?> 